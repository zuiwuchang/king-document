#pragma once
class templateAbout
	:public wxDialog
{
public:
	templateAbout(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &pos=wxDefaultPosition, const wxSize &size=wxDefaultSize, long style=wxDEFAULT_DIALOG_STYLE, const wxString &name=wxDialogNameStr);
	~templateAbout(void);
};

