#include "StdAfx.h"
#include "templateAbout.h"


templateAbout::templateAbout(wxWindow *parent, wxWindowID id, const wxString &title, const wxPoint &pos, const wxSize &size, long style, const wxString &name)
	:wxDialog(parent,id,title,pos,size,style,name)
{
	SetIcon(wxICON(aaaa));
}


templateAbout::~templateAbout(void)
{
}
