#pragma once
#include <wx/app.h>
class templateApp : public wxApp
{
public:
	virtual bool OnInit();
};

