#include "StdAfx.h"
#include "templateApp.h"
#include "templateMain.h"

IMPLEMENT_APP(templateApp);

bool templateApp::OnInit()
{
	templateMain* frame = new templateMain(0L, _("wxWidgets Application Template"));
	frame->SetIcon(wxICON(aaaa)); // To Set App Icon
	frame->Show();
	return true;
}
