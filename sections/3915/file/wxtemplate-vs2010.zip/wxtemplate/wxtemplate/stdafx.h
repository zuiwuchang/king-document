// stdafx.h : ��׼ϵͳ�����ļ��İ����ļ���
// ���Ǿ���ʹ�õ��������ĵ�
// �ض�����Ŀ�İ����ļ�
//

#pragma once

#include "targetver.h"

#define WIN32_LEAN_AND_MEAN             //  �� Windows ͷ�ļ����ų�����ʹ�õ���Ϣ
// Windows ͷ�ļ�:
#include <windows.h>

// C ����ʱͷ�ļ�
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

//wx 
#define __WXMSW__
#define wxUSE_UNICODE

#pragma comment(lib,"comctl32.lib")
#pragma comment(lib,"rpcrt4.lib")

#ifdef _DEBUG
#define __WXDEBUG__
#pragma comment(lib,"wxmsw30ud_stc.lib")
#pragma comment(lib,"wxmsw30ud_propgrid.lib")
#pragma comment(lib,"wxmsw30ud_ribbon.lib")

#pragma comment(lib,"wxscintillad.lib")
#pragma comment(lib,"wxexpatd.lib")
#pragma comment(lib,"wxregexud.lib")
#pragma comment(lib,"wxzlibd.lib")
#pragma comment(lib,"wxtiffd.lib")
#pragma comment(lib,"wxjpegd.lib")
#pragma comment(lib,"wxpngd.lib")
#pragma comment(lib,"wxbase30ud.lib")
#pragma comment(lib,"wxmsw30ud_core.lib")
#pragma comment(lib,"wxmsw30ud_html.lib")
#pragma comment(lib,"wxmsw30ud_adv.lib")
#pragma comment(lib,"wxbase30ud_xml.lib")
#pragma comment(lib,"wxmsw30ud_qa.lib")
#pragma comment(lib,"wxmsw30ud_gl.lib")
#pragma comment(lib,"wxbase30ud_net.lib")
#pragma comment(lib,"wxmsw30ud_media.lib")
#pragma comment(lib,"wxmsw30ud_aui.lib")
#pragma comment(lib,"wxmsw30ud_xrc.lib")
#pragma comment(lib,"wxmsw30ud_richtext.lib")
#pragma comment(lib,"wxmsw30ud_webview.lib")

#else
#pragma comment(lib,"wxmsw30u_stc.lib")
#pragma comment(lib,"wxmsw30u_propgrid.lib")
#pragma comment(lib,"wxmsw30u_ribbon.lib")

#pragma comment(lib,"wxscintilla.lib")
#pragma comment(lib,"wxexpat.lib")
#pragma comment(lib,"wxregexu.lib")
#pragma comment(lib,"wxzlib.lib")
#pragma comment(lib,"wxtiff.lib")
#pragma comment(lib,"wxjpeg.lib")
#pragma comment(lib,"wxpng.lib")
#pragma comment(lib,"wxbase30u.lib")
#pragma comment(lib,"wxmsw30u_core.lib")
#pragma comment(lib,"wxmsw30u_html.lib")
#pragma comment(lib,"wxmsw30u_adv.lib")
#pragma comment(lib,"wxbase30u_xml.lib")
#pragma comment(lib,"wxmsw30u_qa.lib")
#pragma comment(lib,"wxmsw30u_gl.lib")
#pragma comment(lib,"wxbase30u_net.lib")
#pragma comment(lib,"wxmsw30u_media.lib")
#pragma comment(lib,"wxmsw30u_aui.lib")
#pragma comment(lib,"wxmsw30u_xrc.lib")
#pragma comment(lib,"wxmsw30u_richtext.lib")
#pragma comment(lib,"wxmsw30u_webview.lib")
#endif

#include <wx/wx.h>
#include <wx/dialog.h>

// TODO: �ڴ˴����ó�����Ҫ������ͷ�ļ�
